# Product Gallery Carousel with Zoom Effect
## Plugins: Swiper and EasyZoom

*Exemple:* https://codepen.io/k1ngzed/pen/abbjZba

![alt text](https://github.com/k1ngzed/products-gallery-carousel-with-zoom/blob/master/images/products-gallery-carousel-with-zoom.png?raw=true)
